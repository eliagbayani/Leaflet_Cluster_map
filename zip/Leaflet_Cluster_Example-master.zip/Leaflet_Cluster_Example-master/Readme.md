Leaflet Cluster Example
--

Example of creating an interactive map with clustered data using Leaflet and the [Leaflet.markercluster](https://github.com/Leaflet/Leaflet.markercluster) plugin by [Dave Leaver](https://github.com/danzel).

See the post for details: http://asmaloney.com/2015/06/code/clustering-markers-on-leaflet-maps

(The image icons came from here: [clker.com](http://www.clker.com/clipart-google-maps-pin-blue.html))

10 June 2015  
Andy Maloney  
http://asmaloney.com
